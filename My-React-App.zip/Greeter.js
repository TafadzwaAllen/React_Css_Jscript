import React from 'react';

function Greeter (){
    return (<h2>Whats up, React!</h2>);
}
export default Greeter;
