import React from 'react';
import Greeter from './Greeter';

function App() {
  return (
    <div>
    <h1>Welcome to My React App!</h1>
    <Greeter/>{/*Use the Greeter Component */}
    
    </div>);
}

export default App;
 